![](https://github.com/caiofov/.rawMode-Gamedevjs/blob/main/banner.png)

A puzzle plataformer game developed for **Gamedev.js** game jam

Link: https://caiofov.itch.io/raw-mode
